
#include "delay.h"
#include "usart.h"
#include "led.h"

#include "pwm.h"
#include "timer.h"
#include "string.h"
#include "pid.h"
#include "adc.h"
#include "MOTO.h"
#include "STEP.h"
#include "oled.h"

////////////////////////////////////////////////////////////////////////////////// 	 
extern CarState carState;
void test(){
	onboard(0,0,0);
	while(1){}
		
}



